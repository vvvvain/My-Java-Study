package com.daimin.maven;

/**
 * ClassName: Message
 * Package: com.daimin.maven
 * Description:
 *
 * @Author vvvvain
 * @Create 2023/8/16 20:57
 * @Version 1.0
 */
public class Message {

    public String getMessage(){
        return "hello message";
    }
}
