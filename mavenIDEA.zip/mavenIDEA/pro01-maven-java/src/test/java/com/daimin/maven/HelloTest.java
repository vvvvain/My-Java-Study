package com.daimin.maven;

import org.junit.Test;

/**
 * ClassName: HelloTest
 * Package: com.daimin.maven
 * Description:
 *
 * @Author vvvvain
 * @Create 2023/8/16 20:39
 * @Version 1.0
 */
public class HelloTest {

    @Test
    public void testHello(){

        Hello hello = new Hello();

        hello.showMessage();
    }

}
