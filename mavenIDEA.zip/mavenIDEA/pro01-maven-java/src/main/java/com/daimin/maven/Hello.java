package com.daimin.maven;

/**
 * ClassName: Hello
 * Package: com.daimin.maven
 * Description:
 *
 * @Author vvvvain
 * @Create 2023/8/16 20:38
 * @Version 1.0
 */
public class Hello {

    public void showMessage(){
        System.out.println("Hello maven! I am in IDEA now!");
    }
}
